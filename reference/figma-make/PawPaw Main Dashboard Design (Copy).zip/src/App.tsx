import { useState, useRef, useEffect } from 'react'

// ─── Types ─────────────────────────────────────────────────────────────────
type NavId = 'dashboard' | 'chatbot' | 'report' | 'mypet'
type ModalType = null | 'calendar-day' | 'dday-list' | 'weight-input' | 'med-list' | 'pet-guide'
type MedItem = { id: number; name: string; time: string; taken: boolean; color: string }

// ─── Shared nav ────────────────────────────────────────────────────────────
const NAV_ITEMS: { id: NavId; label: string }[] = [
  { id: 'dashboard', label: '대시보드' },
  { id: 'chatbot', label: 'AI챗봇' },
  { id: 'report', label: '건강 레포트' },
  { id: 'mypet', label: '마이펫이지' },
]

// ─── Dashboard data ────────────────────────────────────────────────────────
const WEIGHT_DATA = [
  { day: '7/1', weight: 3.18, entered: true },
  { day: '7/2', weight: 3.18, entered: false },
  { day: '7/3', weight: 3.20, entered: true },
  { day: '7/4', weight: 3.22, entered: true },
  { day: '7/5', weight: 3.21, entered: true },
  { day: '7/6', weight: 3.21, entered: false },
  { day: '7/7', weight: 3.19, entered: true },
  { day: '7/8', weight: 3.18, entered: true },
  { day: '7/9', weight: 3.20, entered: true },
  { day: '7/10', weight: 3.22, entered: true },
  { day: '7/11', weight: 3.24, entered: true },
  { day: '7/12', weight: 3.23, entered: true },
  { day: '7/13', weight: 3.23, entered: false },
  { day: '7/14', weight: 3.21, entered: true },
  { day: '7/15', weight: 3.20, entered: true },
  { day: '7/16', weight: 3.20, entered: false },
  { day: '7/17', weight: 3.21, entered: true },
]

// Medication completion per day in July 2026 (3 meds/day)
const MED_CALENDAR: Record<number, { taken: number; total: number }> = {
  1: { taken: 3, total: 3 }, 2: { taken: 3, total: 3 }, 3: { taken: 3, total: 3 },
  4: { taken: 3, total: 3 }, 5: { taken: 3, total: 3 }, 6: { taken: 3, total: 3 },
  7: { taken: 3, total: 3 }, 8: { taken: 3, total: 3 }, 9: { taken: 3, total: 3 },
  10: { taken: 3, total: 3 }, 11: { taken: 2, total: 3 }, 12: { taken: 3, total: 3 },
  13: { taken: 3, total: 3 }, 14: { taken: 3, total: 3 }, 15: { taken: 3, total: 3 },
  16: { taken: 3, total: 3 }, 17: { taken: 1, total: 3 },
}

const DDAY_ITEMS = [
  { id: 1, name: '광견병 예방접종', dday: 12, date: '2026.07.29', icon: '💉', memo: '새샘 동물병원 예약 완료', urgent: false },
  { id: 2, name: '심장사상충 예방약', dday: 3, date: '2026.07.20', icon: '💊', memo: '집에서 직접 투약 예정', urgent: true },
  { id: 3, name: '정기 건강검진', dday: 28, date: '2026.08.14', icon: '🏥', memo: '체중 측정 및 혈액검사 포함', urgent: false },
]

const INIT_MEDS: MedItem[] = [
  { id: 1, name: '심장사상충 예방약', time: '오전 8:00', taken: true, color: '#9EDAC4' },
  { id: 2, name: '관절 영양제', time: '오후 1:00', taken: false, color: '#C1A7E2' },
  { id: 3, name: '안구 건조증 점안액', time: '오후 5:00', taken: false, color: '#F5D98B' },
]

const HEALTH_ISSUES = [
  { text: '오른쪽 앞발 만질 시 통증 반응', date: '2026.07.14' },
  { text: '계단 오르기 어려움, 앞다리 절뚝거림', date: '2026.07.15' },
  { text: '왼쪽 귀 피부에 작은 두드러기', date: '2026.07.12' },
  { text: '활동량 감소 (평소 대비 약 40%)', date: '2026.07.15' },
]

const PET_GUIDE_TEXT = `포메라니안 종합 안전사항 가이드
AI 분석 결과 · 뽀삐 맞춤 · 2026.07.17

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🍽 식이 관리 (췌장염 관리 중)

• 고지방·고단백 간식 섭취를 삼가주세요.
• 하루 2–3회 소량씩 정해진 시간에 급여하세요.
• 저지방 단백질(닭 가슴살, 연어)을 권장해요.
• 주의 식품: 유제품, 견과류, 지방이 많은 육류.

👁 안구 관리 (안구 건조증 관리 중)

• 처방 점안액을 하루 2회(오전·오후) 정기 투여하세요.
• 건조하거나 바람이 강한 환경에서는 주의가 필요해요.
• 눈 주변 털은 주기적으로 정리해 자극을 줄이세요.
• 이상 증상(과도한 눈곱, 충혈)이 보이면 즉시 내원하세요.

🦴 포메라니안 일반 주의사항

• 높은 곳에서의 낙하를 주의하세요 (소형견은 골절 위험이 높아요).
• 여름철 야외 활동은 30분 이내로 제한하고 더위를 피하세요.
• 목줄보다 하네스(가슴줄) 사용을 권장해요 (기관 허탈 예방).
• 장시간 공복은 저혈당 위험이 있어요 — 규칙적인 급여를 유지하세요.
• 털 엉킴 방지를 위해 주 2–3회 빗질을 권장해요.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
※ 이 가이드는 AI 분석 기반 참고 자료입니다.
   정확한 의료 판단은 수의사와 상담하세요.`

// ─── Shared components ──────────────────────────────────────────────────────
function PawLogo() {
  return (
    <svg width="38" height="38" viewBox="0 0 38 38" fill="none">
      <circle cx="19" cy="19" r="19" fill="#9EDAC4" opacity="0.15" />
      <ellipse cx="19" cy="23" rx="8.5" ry="7" fill="#9EDAC4" />
      <ellipse cx="11.5" cy="15" rx="3.8" ry="4.5" fill="#9EDAC4" />
      <ellipse cx="26.5" cy="15" rx="3.8" ry="4.5" fill="#9EDAC4" />
      <ellipse cx="7" cy="20.5" rx="3" ry="3.8" fill="#C1A7E2" />
      <ellipse cx="31" cy="20.5" rx="3" ry="3.8" fill="#C1A7E2" />
    </svg>
  )
}

function Navbar({ activeNav, setActiveNav }: { activeNav: NavId; setActiveNav: (id: NavId) => void }) {
  const [profileOpen, setProfileOpen] = useState(false)
  return (
    <nav className="sticky top-0 z-40 bg-white" style={{ borderBottom: '1px solid #EDE8E1', boxShadow: '0 1px 12px rgba(58,52,46,0.04)' }} onClick={() => profileOpen && setProfileOpen(false)}>
      <div className="max-w-[1400px] mx-auto px-8 h-[62px] flex items-center gap-6">
        <div className="flex items-center gap-2.5 flex-shrink-0">
          <PawLogo />
          <div>
            <div className="font-black text-[18px] leading-none tracking-tight">
              <span style={{ color: '#3A342E' }}>Paw</span><span style={{ color: '#C1A7E2' }}>:Paw</span>
            </div>
            <div className="text-[10px] font-medium leading-none mt-0.5" style={{ color: '#9EDAC4' }}>우리 아이의 하루를, AI가 함께 돌봐요</div>
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center gap-1">
          {NAV_ITEMS.map(item => (
            <button key={item.id} onClick={e => { e.stopPropagation(); setActiveNav(item.id) }}
              className="px-5 py-2 rounded-full text-[13.5px] transition-all duration-200"
              style={{ backgroundColor: activeNav === item.id ? '#9EDAC4' : 'transparent', color: activeNav === item.id ? 'white' : '#6B6460', fontWeight: activeNav === item.id ? 700 : 400 }}>
              {item.label}
            </button>
          ))}
        </div>
        <div className="relative flex-shrink-0">
          <button onClick={e => { e.stopPropagation(); setProfileOpen(v => !v) }} className="flex items-center gap-2.5 px-3 py-1.5 rounded-full hover:bg-gray-50 transition-colors">
            <span className="text-[13px] font-medium" style={{ color: '#3A342E' }}>김지수 님</span>
            <div className="w-9 h-9 rounded-full overflow-hidden border-2 flex-shrink-0" style={{ borderColor: '#C1A7E2', backgroundColor: '#EDE8F8' }}>
              <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=72&h=72&fit=crop&auto=format" alt="김지수" className="w-full h-full object-cover" />
            </div>
          </button>
          {profileOpen && (
            <div className="absolute right-0 top-full mt-2 bg-white rounded-2xl p-3 min-w-[190px]" style={{ border: '1px solid #EDE8E1', boxShadow: '0 8px 32px rgba(58,52,46,0.12)', zIndex: 50 }} onClick={e => e.stopPropagation()}>
              <div className="text-[11px] font-semibold px-2 mb-2" style={{ color: '#B0A8A0' }}>내 반려동물</div>
              <div className="flex items-center gap-2.5 px-2 py-2 rounded-xl cursor-pointer hover:bg-gray-50 transition-colors">
                <div className="w-9 h-9 rounded-full overflow-hidden border-2 flex-shrink-0" style={{ borderColor: '#9EDAC4' }}>
                  <img src="https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=72&h=72&fit=crop&auto=format" alt="뽀삐" className="w-full h-full object-cover" />
                </div>
                <div><div className="text-[13px] font-semibold">뽀삐</div><div className="text-[11px]" style={{ color: '#B0A8A0' }}>포메라니안 · 3살</div></div>
                <div className="ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ backgroundColor: '#9EDAC4', color: 'white' }}>현재</div>
              </div>
              <div className="flex items-center gap-2.5 px-2 py-2 rounded-xl cursor-pointer hover:bg-gray-50 transition-colors mt-1">
                <div className="w-9 h-9 rounded-full flex items-center justify-center border-2 border-dashed flex-shrink-0" style={{ borderColor: '#C1A7E2' }}>
                  <span className="text-xl leading-none" style={{ color: '#C1A7E2' }}>+</span>
                </div>
                <span className="text-[13px]" style={{ color: '#C1A7E2' }}>반려동물 추가</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </nav>
  )
}

// ─── Modal wrapper ──────────────────────────────────────────────────────────
function Modal({ open, onClose, title, children, maxWidth = 480 }: {
  open: boolean; onClose: () => void; title: string; children: React.ReactNode; maxWidth?: number
}) {
  useEffect(() => {
    if (open) document.body.style.overflow = 'hidden'
    else document.body.style.overflow = ''
    return () => { document.body.style.overflow = '' }
  }, [open])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4" style={{ backgroundColor: 'rgba(58,52,46,0.22)' }} onClick={onClose}>
      <div className="bg-white rounded-3xl shadow-2xl w-full overflow-hidden" style={{ maxWidth }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 flex-shrink-0" style={{ borderBottom: '1px solid #F0ECE8' }}>
          <h3 className="text-[16px] font-black" style={{ color: '#3A342E' }}>{title}</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors text-[22px] leading-none" style={{ color: '#6B6460' }}>×</button>
        </div>
        <div className="overflow-y-auto" style={{ maxHeight: '72vh' }}>{children}</div>
      </div>
    </div>
  )
}

// ─── Weight SVG graph ───────────────────────────────────────────────────────
function WeightGraph() {
  const W = 580, H = 170
  const pad = { t: 12, r: 16, b: 28, l: 44 }
  const cw = W - pad.l - pad.r
  const ch = H - pad.t - pad.b
  const min = 3.14, max = 3.28
  const range = max - min
  const x = (i: number) => pad.l + (i / (WEIGHT_DATA.length - 1)) * cw
  const y = (v: number) => pad.t + ch - ((v - min) / range) * ch
  const linePath = WEIGHT_DATA.map((d, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(d.weight).toFixed(1)}`).join(' ')
  const areaPath = `${linePath} L${x(WEIGHT_DATA.length - 1).toFixed(1)},${(pad.t + ch).toFixed(1)} L${x(0).toFixed(1)},${(pad.t + ch).toFixed(1)} Z`
  const yTicks = [3.16, 3.18, 3.20, 3.22, 3.24, 3.26]
  const today = WEIGHT_DATA[WEIGHT_DATA.length - 1]
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ fontFamily: 'inherit' }}>
      {/* grid */}
      {yTicks.map(v => (
        <g key={v}>
          <line x1={pad.l} y1={y(v)} x2={pad.l + cw} y2={y(v)} stroke="#F0ECE8" strokeWidth="1" />
          <text x={pad.l - 6} y={y(v) + 3.5} textAnchor="end" fontSize="9" fill="#C0BAB4">{v.toFixed(2)}</text>
        </g>
      ))}
      {/* area */}
      <path d={areaPath} fill="#9EDAC4" opacity="0.1" />
      {/* line */}
      <path d={linePath} fill="none" stroke="#9EDAC4" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      {/* non-entered days (dashed segments) */}
      {WEIGHT_DATA.map((d, i) => {
        if (i === 0) return null
        const prev = WEIGHT_DATA[i - 1]
        if (!d.entered && prev.entered) {
          return <line key={i} x1={x(i - 1)} y1={y(prev.weight)} x2={x(i)} y2={y(d.weight)} stroke="#C1A7E2" strokeWidth="1.5" strokeDasharray="4 3" opacity="0.6" />
        }
        return null
      })}
      {/* x axis labels */}
      {WEIGHT_DATA.map((d, i) => {
        if (i === 0 || i === 4 || i === 8 || i === 12 || i === 16) {
          return <text key={i} x={x(i)} y={H - 6} textAnchor="middle" fontSize="9" fill="#C0BAB4">{d.day}</text>
        }
        return null
      })}
      {/* today dot */}
      <circle cx={x(WEIGHT_DATA.length - 1)} cy={y(today.weight)} r="5" fill="#9EDAC4" stroke="white" strokeWidth="2.5" />
      {/* today label */}
      <text x={x(WEIGHT_DATA.length - 1)} y={y(today.weight) - 10} textAnchor="middle" fontSize="10" fontWeight="700" fill="#5BB898">{today.weight.toFixed(2)}</text>
    </svg>
  )
}

// ─── Calendar grid ──────────────────────────────────────────────────────────
function CalendarCard({ onDayClick }: { onDayClick: (day: number) => void }) {
  const [offset, setOffset] = useState(0) // month offset from July 2026
  // July 2026: first day = Wednesday = index 3 (Sun=0)
  const today = 17
  const daysInMonth = 31
  const firstDayOffset = 3 // Wednesday
  const monthName = offset === 0 ? '2026년 7월' : offset === 1 ? '2026년 8월' : '2026년 6월'
  const DAY_LABELS = ['일', '월', '화', '수', '목', '금', '토']

  // Build cells array
  const cells: (number | null)[] = []
  for (let i = 0; i < firstDayOffset; i++) cells.push(null)
  for (let d = 1; d <= daysInMonth; d++) cells.push(d)
  while (cells.length % 7 !== 0) cells.push(null)

  return (
    <div className="rounded-3xl p-5" style={{ backgroundColor: 'white', border: '1px solid #EDE8E1', boxShadow: '0 2px 16px rgba(58,52,46,0.06)' }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <button onClick={() => setOffset(v => v - 1)} className="w-7 h-7 rounded-xl flex items-center justify-center hover:bg-gray-100 transition-colors text-[14px]" style={{ color: '#6B6460' }}>◀</button>
        <span className="text-[15px] font-black" style={{ color: '#3A342E' }}>{monthName}</span>
        <button onClick={() => setOffset(v => v + 1)} className="w-7 h-7 rounded-xl flex items-center justify-center hover:bg-gray-100 transition-colors text-[14px]" style={{ color: '#6B6460' }}>▶</button>
      </div>
      {/* Day headers */}
      <div className="grid grid-cols-7 mb-1">
        {DAY_LABELS.map((d, i) => (
          <div key={d} className="text-center text-[10px] font-bold py-1" style={{ color: i === 0 ? '#E8837A' : i === 6 ? '#9EDAC4' : '#B0A8A0' }}>{d}</div>
        ))}
      </div>
      {/* Calendar cells */}
      <div className="grid grid-cols-7 gap-0.5">
        {cells.map((day, idx) => {
          if (day === null) return <div key={idx} />
          const isToday = day === today && offset === 0
          const medData = offset === 0 ? MED_CALENDAR[day] : undefined
          const isComplete = medData && medData.taken === medData.total
          const isMissed = medData && medData.taken < medData.total
          const isFuture = offset !== 0 || day > today
          return (
            <div key={idx} onClick={() => !isFuture && onDayClick(day)}
              className="relative flex flex-col items-center py-1 rounded-xl transition-all"
              style={{ cursor: isFuture ? 'default' : 'pointer' }}
            >
              <div className="w-7 h-7 flex items-center justify-center rounded-full text-[12px] font-semibold transition-all hover:scale-110"
                style={{
                  backgroundColor: isToday ? '#C1A7E2' : 'transparent',
                  color: isToday ? 'white' : idx % 7 === 0 ? '#E8837A' : idx % 7 === 6 ? '#5BB898' : '#3A342E',
                  fontWeight: isToday ? 800 : 500,
                }}>
                {day}
              </div>
              {medData && (
                <div className="text-[8.5px] font-bold mt-0.5 leading-none"
                  style={{ color: isComplete ? '#5BB898' : isMissed ? '#E8837A' : '#C0BAB4' }}>
                  {medData.taken}/{medData.total}
                </div>
              )}
            </div>
          )
        })}
      </div>
      {/* Legend */}
      <div className="flex items-center gap-4 mt-3 pt-3" style={{ borderTop: '1px solid #F0ECE8' }}>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-bold" style={{ color: '#5BB898' }}>n/m</span>
          <span className="text-[10px]" style={{ color: '#B0A8A0' }}>복용 완료</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-bold" style={{ color: '#E8837A' }}>n/m</span>
          <span className="text-[10px]" style={{ color: '#B0A8A0' }}>미복용</span>
        </div>
        <div className="ml-auto flex items-center gap-1">
          <div className="w-3.5 h-3.5 rounded-full flex items-center justify-center" style={{ backgroundColor: '#C1A7E2' }}><span className="text-[7px] text-white font-bold">●</span></div>
          <span className="text-[10px]" style={{ color: '#B0A8A0' }}>오늘</span>
        </div>
      </div>
    </div>
  )
}

// ─── Dashboard cards ────────────────────────────────────────────────────────
function BasicInfoCard({ onGuide }: { onGuide: () => void }) {
  return (
    <div className="rounded-3xl p-5" style={{ backgroundColor: 'white', border: '1px solid #EDE8E1', boxShadow: '0 2px 16px rgba(58,52,46,0.06)' }}>
      <div className="flex items-start gap-5">
        {/* Left: pet info */}
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 rounded-2xl overflow-hidden flex-shrink-0" style={{ border: '2.5px solid #C1A7E2', backgroundColor: '#EDE8F8' }}>
              <img src="https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=112&h=112&fit=crop&auto=format" alt="뽀삐" className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="text-[20px] font-black leading-tight" style={{ color: '#3A342E' }}>뽀삐</div>
              <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                {['포메라니안', '3살', '여아 ♀'].map(tag => (
                  <span key={tag} className="text-[11px] font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: '#F4F0FB', color: '#9A75CC' }}>{tag}</span>
                ))}
              </div>
            </div>
          </div>
          {/* Stats row */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            {[
              { label: '체중', value: '3.21 kg' },
              { label: '나이', value: '3년 2개월' },
              { label: '중성화', value: '완료' },
            ].map(s => (
              <div key={s.label} className="rounded-2xl px-3 py-2.5 text-center" style={{ backgroundColor: '#F8F6FF' }}>
                <div className="text-[10px] mb-0.5" style={{ color: '#B0A8A0' }}>{s.label}</div>
                <div className="text-[12px] font-bold" style={{ color: '#3A342E' }}>{s.value}</div>
              </div>
            ))}
          </div>
          {/* Managed diseases */}
          <div>
            <div className="text-[11px] font-bold mb-2" style={{ color: '#B0A8A0' }}>관리중인 질병</div>
            <div className="flex flex-wrap gap-1.5">
              {['췌장염', '안구 건조증'].map(d => (
                <span key={d} className="flex items-center gap-1 text-[12px] font-semibold px-3 py-1 rounded-full" style={{ backgroundColor: '#FFF3F2', color: '#E8837A', border: '1px solid #FFCFCC' }}>
                  <span>●</span>{d}
                </span>
              ))}
              <button className="text-[11px] px-3 py-1 rounded-full border-2 border-dashed transition-colors hover:bg-gray-50" style={{ borderColor: '#EDE8E1', color: '#B0A8A0' }}>+ 추가</button>
            </div>
          </div>
        </div>

        {/* Right: pet guide */}
        <div className="w-[200px] flex-shrink-0 rounded-2xl p-4" style={{ backgroundColor: '#F4F0FB', border: '1px solid #E8DFF8' }}>
          <div className="flex items-center gap-1.5 mb-3">
            <span className="text-sm">🤖</span>
            <span className="text-[12px] font-black" style={{ color: '#7A5FC0' }}>내 반려동물 가이드</span>
          </div>
          <p className="text-[11px] mb-3 leading-relaxed" style={{ color: '#8B7BB0' }}>AI가 종 정보와 현재 건강 상태 기반으로 분석한 안전사항이에요.</p>
          <ul className="flex flex-col gap-1.5 mb-4">
            {[
              '고지방 식품 섭취 주의 (췌장염)',
              '높은 곳 낙하 주의 (골절 위험)',
              '하네스 사용 권장 (기관 허탈)',
              '점안액 하루 2회 정기 투약',
            ].map((tip, i) => (
              <li key={i} className="flex items-start gap-1.5 text-[11px]" style={{ color: '#6B6460' }}>
                <span className="flex-shrink-0 mt-0.5" style={{ color: '#C1A7E2' }}>•</span>{tip}
              </li>
            ))}
          </ul>
          <button onClick={onGuide} className="w-full py-2 rounded-xl text-[11.5px] font-bold text-white transition-opacity hover:opacity-85" style={{ backgroundColor: '#3A342E' }}>
            안전사항 문서보기
          </button>
        </div>
      </div>
    </div>
  )
}

function DdayCard({ name, dday, date, icon, urgent, onList }: {
  name: string; dday: number; date: string; icon: string; urgent: boolean; onList: () => void
}) {
  return (
    <div className="rounded-3xl p-5 flex flex-col" style={{ backgroundColor: urgent ? '#FFF3F2' : '#FFF9EC', border: `1px solid ${urgent ? '#FFCFCC' : '#FFE9A0'}` }}>
      <div className="flex items-start justify-between mb-3">
        <span className="text-2xl">{icon}</span>
        <div className="flex flex-col items-end">
          <div className="text-[9px] font-black leading-none" style={{ color: urgent ? '#E8837A' : '#D4900A' }}>D-</div>
          <div className="text-[36px] font-black leading-none" style={{ color: urgent ? '#E8837A' : '#D4900A', lineHeight: 1 }}>{dday}</div>
        </div>
      </div>
      <div className="flex-1">
        <div className="text-[14px] font-black mb-1" style={{ color: '#3A342E' }}>{name}</div>
        <div className="text-[11px]" style={{ color: '#B0A8A0' }}>{date}</div>
      </div>
      <button onClick={onList} className="mt-4 w-full py-2 rounded-xl text-[12px] font-bold transition-opacity hover:opacity-75" style={{ backgroundColor: urgent ? '#E8837A' : '#F5D98B', color: urgent ? 'white' : '#7A5800' }}>
        목록 확인
      </button>
    </div>
  )
}

function WeightCard({ weight, onEdit }: { weight: string; onEdit: () => void }) {
  const prevWeight = 3.20
  const curr = parseFloat(weight)
  const diff = curr - prevWeight
  const sign = diff > 0 ? '+' : ''
  return (
    <div className="rounded-3xl p-5 flex flex-col" style={{ backgroundColor: '#EDF9F4', border: '1px solid #C8EDE0' }}>
      <div className="text-[12px] font-bold mb-1" style={{ color: '#5BB898' }}>오늘의 몸무게</div>
      <div className="flex items-baseline gap-1.5 mb-1">
        <span className="text-[38px] font-black leading-none" style={{ color: '#3A342E' }}>{weight}</span>
        <span className="text-[16px] font-bold" style={{ color: '#6B6460' }}>kg</span>
      </div>
      <div className="text-[11px] mb-4" style={{ color: diff > 0 ? '#E8837A' : diff < 0 ? '#5BB898' : '#B0A8A0' }}>
        {sign}{diff.toFixed(2)}kg {diff > 0 ? '↑' : diff < 0 ? '↓' : '—'} 어제보다
      </div>
      <button onClick={onEdit} className="mt-auto w-full py-2 rounded-xl text-[12px] font-bold text-white transition-opacity hover:opacity-85" style={{ backgroundColor: '#9EDAC4' }}>
        작성/변경하기
      </button>
    </div>
  )
}

function MedCard({ taken, total, onList }: { taken: number; total: number; onList: () => void }) {
  const done = taken === total
  return (
    <div className="rounded-3xl p-5 flex flex-col" style={{ backgroundColor: done ? '#F4F0FB' : '#FFF3F2', border: `1px solid ${done ? '#E8DFF8' : '#FFCFCC'}` }}>
      <div className="text-[12px] font-bold mb-1" style={{ color: done ? '#9A75CC' : '#E8837A' }}>오늘 복용한 약</div>
      <div className="flex items-baseline gap-1.5 mb-1">
        <span className="text-[38px] font-black leading-none" style={{ color: done ? '#3A342E' : '#E8837A' }}>{taken}/{total}</span>
        <span className="text-[16px] font-bold" style={{ color: '#6B6460' }}>개</span>
      </div>
      <div className="text-[11px] mb-4" style={{ color: done ? '#9A75CC' : '#E8837A' }}>
        {done ? '오늘 복약 완료! 🎉' : `${total - taken}개 미복용`}
      </div>
      <button onClick={onList} className="mt-auto w-full py-2 rounded-xl text-[12px] font-bold text-white transition-opacity hover:opacity-85" style={{ backgroundColor: done ? '#C1A7E2' : '#E8837A' }}>
        리스트 확인
      </button>
    </div>
  )
}

function WeightGraphCard() {
  return (
    <div className="rounded-3xl p-5" style={{ backgroundColor: 'white', border: '1px solid #EDE8E1', boxShadow: '0 2px 16px rgba(58,52,46,0.06)' }}>
      <div className="flex items-center justify-between mb-3">
        <span className="text-[14px] font-black" style={{ color: '#3A342E' }}>뽀삐의 이번달 체중 변화</span>
        <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full" style={{ backgroundColor: '#EDF9F4', color: '#5BB898' }}>2026.07</span>
      </div>
      <WeightGraph />
      <div className="flex items-center justify-between mt-1">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="w-5 h-0.5 rounded-full" style={{ backgroundColor: '#9EDAC4' }} />
            <span className="text-[10px]" style={{ color: '#B0A8A0' }}>입력일</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-5 h-0.5 rounded-full" style={{ backgroundColor: '#C1A7E2', borderTop: '1px dashed #C1A7E2' }} />
            <span className="text-[10px]" style={{ color: '#B0A8A0' }}>미입력 (전일 동일)</span>
          </div>
        </div>
        <span className="text-[10px]" style={{ color: '#B0A8A0' }}>최근: 17일</span>
      </div>
    </div>
  )
}

function HealthCard() {
  return (
    <div className="rounded-3xl p-5 flex-1" style={{ backgroundColor: 'white', border: '1px solid #EDE8E1', boxShadow: '0 2px 16px rgba(58,52,46,0.06)' }}>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-7 h-7 rounded-xl flex items-center justify-center text-base" style={{ backgroundColor: '#EDF9F4' }}>🐾</div>
        <span className="text-[15px] font-black" style={{ color: '#3A342E' }}>뽀삐의 건강</span>
        <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full" style={{ backgroundColor: '#FFF3F2', color: '#E8837A', border: '1px solid #FFCFCC' }}>AI 자동 반영</span>
      </div>

      {/* 주요 이상부위 */}
      <div className="mb-4">
        <div className="text-[11px] font-bold mb-2" style={{ color: '#B0A8A0' }}>주요 이상부위</div>
        <div className="flex flex-wrap gap-1.5">
          {['오른쪽 앞발', '오른쪽 귀'].map(part => (
            <span key={part} className="flex items-center gap-1 text-[12px] font-semibold px-3 py-1.5 rounded-full" style={{ backgroundColor: '#FFE0DE', color: '#C0504A' }}>
              <span>⚠</span>{part}
            </span>
          ))}
        </div>
      </div>

      {/* 특이사항 */}
      <div>
        <div className="text-[11px] font-bold mb-2" style={{ color: '#B0A8A0' }}>특이사항 (AI 챗봇 자동 반영)</div>
        <ul className="flex flex-col gap-2">
          {HEALTH_ISSUES.map((issue, i) => (
            <li key={i} className="flex items-start justify-between gap-3 py-2.5 px-3 rounded-2xl" style={{ backgroundColor: '#FDFCF9', border: '1px solid #EDE8E1' }}>
              <div className="flex items-start gap-2 min-w-0">
                <span className="w-1.5 h-1.5 rounded-full flex-shrink-0 mt-1.5" style={{ backgroundColor: '#E8837A' }} />
                <span className="text-[12.5px] leading-snug" style={{ color: '#3A342E' }}>{issue.text}</span>
              </div>
              <span className="text-[10px] flex-shrink-0" style={{ color: '#C0BAB4' }}>{issue.date.slice(5)}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

// ─── Modal contents ─────────────────────────────────────────────────────────
function CalendarDayModal({ day, onClose }: { day: number; onClose: () => void }) {
  const medData = MED_CALENDAR[day]
  const [checked, setChecked] = useState([
    { name: '심장사상충 예방약', time: '오전 8:00', taken: true, color: '#9EDAC4' },
    { name: '관절 영양제', time: '오후 1:00', taken: day < 17 ? true : false, color: '#C1A7E2' },
    { name: '안구 건조증 점안액', time: '오후 5:00', taken: day < 16 ? true : false, color: '#F5D98B' },
  ])
  const toggle = (i: number) => setChecked(prev => prev.map((m, idx) => idx === i ? { ...m, taken: !m.taken } : m))
  return (
    <Modal open onClose={onClose} title={`7월 ${day}일 복약 현황`}>
      <div className="px-6 py-4">
        <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-2xl" style={{ backgroundColor: '#F8F6FF' }}>
          <span className="text-sm">📅</span>
          <span className="text-[12px]" style={{ color: '#8B7BB0' }}>날짜를 클릭해 복약 여부를 변경할 수 있어요.</span>
        </div>
        <ul className="flex flex-col gap-2.5">
          {checked.map((m, i) => (
            <li key={i} onClick={() => toggle(i)}
              className="flex items-center gap-3 px-4 py-3 rounded-2xl cursor-pointer transition-all hover:scale-[1.01]"
              style={{ backgroundColor: m.taken ? '#F0FBF7' : '#FFF8F8', border: `1.5px solid ${m.taken ? '#C8EDE0' : '#FFD5D5'}` }}>
              <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors"
                style={{ borderColor: m.taken ? '#9EDAC4' : '#FFCFCC', backgroundColor: m.taken ? '#9EDAC4' : 'transparent' }}>
                {m.taken && <span className="text-[10px] text-white font-bold">✓</span>}
              </div>
              <div className="flex-1">
                <div className="text-[13px] font-semibold" style={{ color: '#3A342E' }}>{m.name}</div>
                <div className="text-[11px]" style={{ color: '#B0A8A0' }}>{m.time}</div>
              </div>
              <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: m.color }} />
            </li>
          ))}
        </ul>
        <button onClick={onClose} className="mt-5 w-full py-3 rounded-2xl text-[13px] font-bold text-white" style={{ backgroundColor: '#9EDAC4' }}>저장하기</button>
      </div>
    </Modal>
  )
}

function DdayListModal({ onClose }: { onClose: () => void }) {
  const [items, setItems] = useState(DDAY_ITEMS)
  return (
    <Modal open onClose={onClose} title="D-day 일정 목록" maxWidth={500}>
      <div className="px-6 py-4">
        <ul className="flex flex-col gap-3 mb-4">
          {items.map(item => (
            <li key={item.id} className="flex items-start gap-3 p-4 rounded-2xl" style={{ backgroundColor: item.urgent ? '#FFF3F2' : '#FFF9EC', border: `1px solid ${item.urgent ? '#FFCFCC' : '#FFE9A0'}` }}>
              <span className="text-xl mt-0.5">{item.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[14px] font-black" style={{ color: '#3A342E' }}>{item.name}</span>
                  <span className="text-[12px] font-black" style={{ color: item.urgent ? '#E8837A' : '#D4900A' }}>D-{item.dday}</span>
                </div>
                <div className="text-[11px] mb-1" style={{ color: '#B0A8A0' }}>{item.date}</div>
                <div className="text-[12px]" style={{ color: '#6B6460' }}>{item.memo}</div>
              </div>
              <button onClick={() => setItems(prev => prev.filter(i => i.id !== item.id))} className="w-6 h-6 rounded-full flex items-center justify-center text-[14px] hover:bg-gray-100 flex-shrink-0" style={{ color: '#C0BAB4' }}>×</button>
            </li>
          ))}
        </ul>
        <button className="w-full py-3 rounded-2xl text-[13px] font-bold border-2 border-dashed transition-colors hover:bg-gray-50" style={{ borderColor: '#EDE8E1', color: '#B0A8A0' }}>
          + 일정 추가하기
        </button>
      </div>
    </Modal>
  )
}

function WeightInputModal({ currentWeight, onSave, onClose }: { currentWeight: string; onSave: (w: string) => void; onClose: () => void }) {
  const [val, setVal] = useState(currentWeight)
  return (
    <Modal open onClose={onClose} title="체중 기록" maxWidth={380}>
      <div className="px-6 py-4">
        <div className="text-[12px] mb-3" style={{ color: '#B0A8A0' }}>오늘 뽀삐의 체중을 입력해주세요.</div>
        <div className="flex items-center gap-3 mb-5">
          <input type="number" step="0.01" min="0" max="20" value={val} onChange={e => setVal(e.target.value)}
            className="flex-1 text-[28px] font-black text-center outline-none rounded-2xl py-3"
            style={{ backgroundColor: '#F0FBF7', border: '2px solid #9EDAC4', color: '#3A342E' }} />
          <span className="text-[18px] font-bold flex-shrink-0" style={{ color: '#6B6460' }}>kg</span>
        </div>
        <div className="grid grid-cols-4 gap-2 mb-5">
          {[3.18, 3.19, 3.20, 3.21, 3.22, 3.23, 3.24, 3.25].map(w => (
            <button key={w} onClick={() => setVal(w.toFixed(2))}
              className="py-2 rounded-xl text-[12px] font-semibold transition-all hover:scale-105"
              style={{ backgroundColor: val === w.toFixed(2) ? '#9EDAC4' : '#F0FBF7', color: val === w.toFixed(2) ? 'white' : '#5BB898' }}>
              {w.toFixed(2)}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 py-3 rounded-2xl text-[13px] font-bold border-2" style={{ borderColor: '#EDE8E1', color: '#6B6460' }}>취소</button>
          <button onClick={() => onSave(val)} className="flex-1 py-3 rounded-2xl text-[13px] font-bold text-white" style={{ backgroundColor: '#9EDAC4' }}>저장</button>
        </div>
      </div>
    </Modal>
  )
}

function MedListModal({ meds, onChange, onClose }: { meds: MedItem[]; onChange: (m: MedItem[]) => void; onClose: () => void }) {
  const toggle = (id: number) => onChange(meds.map(m => m.id === id ? { ...m, taken: !m.taken } : m))
  const remove = (id: number) => onChange(meds.filter(m => m.id !== id))
  return (
    <Modal open onClose={onClose} title="복약 리스트 관리" maxWidth={480}>
      <div className="px-6 py-4">
        <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-2xl" style={{ backgroundColor: '#F8F6FF' }}>
          <span className="text-sm">💡</span>
          <span className="text-[11.5px]" style={{ color: '#8B7BB0' }}>약 이름을 클릭해 복용 여부를 변경하거나, ✕로 삭제할 수 있어요.</span>
        </div>
        <ul className="flex flex-col gap-2.5 mb-4">
          {meds.map(m => (
            <li key={m.id} className="flex items-center gap-3 px-4 py-3 rounded-2xl"
              style={{ backgroundColor: m.taken ? '#F0FBF7' : 'white', border: `1.5px solid ${m.taken ? '#C8EDE0' : '#EDE8E1'}` }}>
              <button onClick={() => toggle(m.id)} className="w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all"
                style={{ borderColor: m.taken ? '#9EDAC4' : '#D5D0CA', backgroundColor: m.taken ? '#9EDAC4' : 'transparent' }}>
                {m.taken && <span className="text-[10px] text-white font-bold">✓</span>}
              </button>
              <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: m.color }} />
              <div className="flex-1">
                <div className="text-[13px] font-semibold" style={{ color: '#3A342E', textDecoration: m.taken ? 'line-through' : 'none', opacity: m.taken ? 0.6 : 1 }}>{m.name}</div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] px-2 py-0.5 rounded-lg" style={{ backgroundColor: '#F4F0FB', color: '#9A75CC' }}>{m.time}</span>
                <button onClick={() => remove(m.id)} className="w-5 h-5 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors text-[14px]" style={{ color: '#C0BAB4' }}>×</button>
              </div>
            </li>
          ))}
        </ul>
        <button className="w-full py-3 rounded-2xl text-[13px] font-bold border-2 border-dashed mb-3 transition-colors hover:bg-gray-50" style={{ borderColor: '#EDE8E1', color: '#B0A8A0' }}>
          + 약 추가하기
        </button>
        <button onClick={onClose} className="w-full py-3 rounded-2xl text-[13px] font-bold text-white" style={{ backgroundColor: '#9EDAC4' }}>확인</button>
      </div>
    </Modal>
  )
}

function PetGuideModal({ onClose }: { onClose: () => void }) {
  return (
    <Modal open onClose={onClose} title="포메라니안 안전사항 가이드" maxWidth={560}>
      <div className="px-6 py-4">
        <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-2xl" style={{ backgroundColor: '#F4F0FB' }}>
          <span>🤖</span>
          <span className="text-[11.5px]" style={{ color: '#8B7BB0' }}>AI 분석 기반 · 뽀삐 맞춤 생성 · 2026.07.17</span>
        </div>
        <pre className="text-[12.5px] leading-relaxed whitespace-pre-wrap rounded-2xl p-4 mb-4" style={{ backgroundColor: '#FDFCF9', border: '1px solid #EDE8E1', color: '#3A342E', fontFamily: 'inherit' }}>
          {PET_GUIDE_TEXT}
        </pre>
        <div className="flex gap-2">
          <button className="flex-1 py-3 rounded-2xl text-[13px] font-bold border-2 flex items-center justify-center gap-2 transition-colors hover:bg-gray-50" style={{ borderColor: '#EDE8E1', color: '#6B6460' }}>
            <span>📥</span> 파일 저장
          </button>
          <button onClick={onClose} className="flex-1 py-3 rounded-2xl text-[13px] font-bold text-white" style={{ backgroundColor: '#3A342E' }}>닫기</button>
        </div>
      </div>
    </Modal>
  )
}

// ─── Full Dashboard Page ────────────────────────────────────────────────────
function FullDashboardPage({ onChatbot }: { onChatbot: () => void }) {
  const [modal, setModal] = useState<ModalType>(null)
  const [selectedDay, setSelectedDay] = useState<number>(17)
  const [weight, setWeight] = useState('3.21')
  const [meds, setMeds] = useState<MedItem[]>(INIT_MEDS)
  const [editMode, setEditMode] = useState(false)
  const takenCount = meds.filter(m => m.taken).length

  return (
    <div className="max-w-[1440px] mx-auto px-8 py-5 pb-10">
      {/* Page header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-[22px] font-black leading-tight" style={{ color: '#3A342E' }}>뽀삐의 대시보드</h1>
          <p className="text-[12px] mt-0.5" style={{ color: '#B0A8A0' }}>2026년 7월 17일 금요일 · 마지막 업데이트 오전 8:04</p>
        </div>
        {editMode && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full" style={{ backgroundColor: '#FFF3F2', border: '1px solid #FFCFCC' }}>
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: '#E8837A' }} />
            <span className="text-[12px] font-semibold" style={{ color: '#E8837A' }}>편집 모드</span>
          </div>
        )}
      </div>

      {/* Main 2-column grid */}
      <div className="flex gap-5">
        {/* Left column */}
        <div className="flex flex-col gap-4" style={{ flex: '1.15' }}>
          <BasicInfoCard onGuide={() => setModal('pet-guide')} />

          {/* D-day cards */}
          <div className="grid grid-cols-2 gap-4">
            <DdayCard name="광견병 예방접종" dday={12} date="2026.07.29" icon="💉" urgent={false} onList={() => setModal('dday-list')} />
            <DdayCard name="심장사상충 예방약" dday={3} date="2026.07.20" icon="💊" urgent={true} onList={() => setModal('dday-list')} />
          </div>

          {/* Weight + Meds cards */}
          <div className="grid grid-cols-2 gap-4">
            <WeightCard weight={weight} onEdit={() => setModal('weight-input')} />
            <MedCard taken={takenCount} total={meds.length} onList={() => setModal('med-list')} />
          </div>

          {/* Weight graph */}
          <WeightGraphCard />
        </div>

        {/* Right column */}
        <div className="flex flex-col gap-4" style={{ flex: '0.85' }}>
          <CalendarCard onDayClick={day => { setSelectedDay(day); setModal('calendar-day') }} />
          <HealthCard />
        </div>
      </div>

      {/* Edit button */}
      <div className="mt-5">
        <button
          onClick={() => setEditMode(v => !v)}
          className="w-full py-4 rounded-2xl text-[15px] font-black text-white transition-all hover:opacity-90 active:scale-[0.99]"
          style={{ backgroundColor: editMode ? '#E8837A' : '#3A342E', boxShadow: '0 4px 20px rgba(58,52,46,0.2)' }}
        >
          {editMode ? '편집 완료' : '편집하기'}
        </button>
      </div>

      {/* Modals */}
      {modal === 'calendar-day' && <CalendarDayModal day={selectedDay} onClose={() => setModal(null)} />}
      {modal === 'dday-list' && <DdayListModal onClose={() => setModal(null)} />}
      {modal === 'weight-input' && <WeightInputModal currentWeight={weight} onSave={w => { setWeight(w); setModal(null) }} onClose={() => setModal(null)} />}
      {modal === 'med-list' && <MedListModal meds={meds} onChange={setMeds} onClose={() => setModal(null)} />}
      {modal === 'pet-guide' && <PetGuideModal onClose={() => setModal(null)} />}

      {/* Floating chatbot button */}
      <button
        onClick={onChatbot}
        className="fixed bottom-8 right-8 w-[58px] h-[58px] rounded-full flex items-center justify-center transition-transform hover:scale-110 active:scale-95"
        style={{ background: 'linear-gradient(135deg, #9EDAC4 0%, #C1A7E2 100%)', boxShadow: '0 6px 24px rgba(158,218,196,0.5)', zIndex: 50 }}
      >
        <svg width="27" height="27" viewBox="0 0 27 27" fill="none">
          <path d="M3.5 5C3.5 3.9 4.4 3 5.5 3H21.5C22.6 3 23.5 3.9 23.5 5V17C23.5 18.1 22.6 19 21.5 19H9L3.5 24.5V5Z" fill="white" opacity="0.95" />
          <circle cx="10" cy="12" r="1.6" fill="#9EDAC4" />
          <circle cx="13.5" cy="12" r="1.6" fill="#9EDAC4" />
          <circle cx="17" cy="12" r="1.6" fill="#9EDAC4" />
        </svg>
      </button>
    </div>
  )
}

// ─── Chatbot page (unchanged) ──────────────────────────────────────────────
function ChatDogDecor() {
  return (
    <svg width="90" height="95" viewBox="0 0 90 95" fill="none">
      <ellipse cx="45" cy="90" rx="30" ry="5" fill="#D4C9B8" opacity="0.4" />
      <path d="M68 70 Q84 60 78 48 Q74 40 66 46" stroke="#E8A84E" strokeWidth="7" strokeLinecap="round" fill="none" />
      <ellipse cx="45" cy="72" rx="27" ry="22" fill="#F9C74F" />
      <ellipse cx="25" cy="33" rx="10" ry="17" fill="#E8A84E" transform="rotate(-15 25 33)" />
      <ellipse cx="65" cy="33" rx="10" ry="17" fill="#E8A84E" transform="rotate(15 65 33)" />
      <ellipse cx="25" cy="33" rx="6" ry="11" fill="#F9C74F" opacity="0.6" transform="rotate(-15 25 33)" />
      <ellipse cx="65" cy="33" rx="6" ry="11" fill="#F9C74F" opacity="0.6" transform="rotate(15 65 33)" />
      <circle cx="45" cy="40" r="26" fill="#F9C74F" />
      <circle cx="36" cy="38" r="6" fill="#3A342E" /><circle cx="54" cy="38" r="6" fill="#3A342E" />
      <circle cx="37.5" cy="36.5" r="2" fill="white" /><circle cx="55.5" cy="36.5" r="2" fill="white" />
      <ellipse cx="45" cy="48" rx="5" ry="4" fill="#3A342E" />
      <path d="M39 54 Q45 60 51 54" stroke="#3A342E" strokeWidth="1.5" fill="none" strokeLinecap="round" />
      <circle cx="30" cy="45" r="6" fill="#FFB5BA" opacity="0.4" /><circle cx="60" cy="45" r="6" fill="#FFB5BA" opacity="0.4" />
      <rect x="30" y="60" width="30" height="6" rx="3" fill="#9EDAC4" />
      <circle cx="45" cy="63" r="2.5" fill="#C1A7E2" />
      <ellipse cx="33" cy="90" rx="9" ry="6" fill="#F9C74F" /><ellipse cx="57" cy="90" rx="9" ry="6" fill="#F9C74F" />
    </svg>
  )
}

function TypingDots() {
  return (
    <div className="flex items-center gap-1 px-1 py-1">
      {[0, 1, 2].map(i => (
        <div key={i} className="w-2 h-2 rounded-full" style={{ backgroundColor: '#C1A7E2', animation: `bounce 1.2s ease-in-out ${i * 0.2}s infinite` }} />
      ))}
      <style>{`@keyframes bounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-6px)}}`}</style>
    </div>
  )
}

function AiResponseBody() {
  const conditions = [
    { name: '슬개골 탈구', english: 'Patellar Luxation', stat: '포메라니안·소형견에서 유사 증상을 보이는 4살 소형견의 약 38%에서 관찰됩니다.', source: 'AVMA Companion Animal Parasite Report 2024' },
    { name: '관절염', english: 'Osteoarthritis', stat: '4살 소형견에서 통계적으로 약 22%가 보행 이상으로 처음 발견됩니다.', source: 'Journal of Veterinary Internal Medicine, 2023' },
    { name: '연부조직 손상', english: 'Soft Tissue Injury', stat: '갑작스러운 운동이나 낙하 후 발생하며, 비슷한 증상을 보이는 경우의 약 18%에서 관찰됩니다.', source: 'VCA Animal Hospitals Clinical Guidelines' },
  ]
  return (
    <div className="text-[13.5px] leading-relaxed" style={{ color: '#3A342E' }}>
      <p className="mb-3">뽀삐의 증상을 알려주셔서 감사해요 🐾</p>
      <p className="mb-3">다리를 절고 계단 오르기를 힘들어하는 증상이 있다면, 몇 가지 상태가 있을지도 몰라요.</p>
      <div className="rounded-2xl px-4 py-3 mb-3 flex items-start gap-2" style={{ backgroundColor: '#FFF9EC', border: '1px solid #FFE5A0' }}>
        <span className="text-sm mt-0.5">⚠️</span>
        <p className="text-[12px]" style={{ color: '#8A6E20' }}>아래 내용은 <strong>참고용</strong>이에요. 정확한 진단은 반드시 수의사를 통해 받으셔야 해요.</p>
      </div>
      <div className="flex flex-col gap-3 mb-3">
        {conditions.map((c, i) => (
          <div key={i} className="rounded-2xl p-3.5" style={{ backgroundColor: '#F8F5FF', border: '1px solid #E8DFF8' }}>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-[13px] font-bold" style={{ color: '#3A342E' }}>{c.name}</span>
              <span className="text-[11px]" style={{ color: '#9A8FB0' }}>({c.english})</span>
            </div>
            <p className="text-[12px] mb-1.5" style={{ color: '#5A5258' }}>{c.stat}</p>
            <span className="text-[11px] px-2 py-0.5 rounded-full cursor-pointer hover:opacity-80" style={{ backgroundColor: '#EDE8F8', color: '#8B6FC7' }}>📎 출처: {c.source}</span>
          </div>
        ))}
      </div>
      <p className="text-[13px]" style={{ color: '#6B6460' }}>뽀삐의 정확한 상태 확인을 위해 가까운 동물병원에서 검진을 받아보시는 것을 권장드려요 🏥</p>
    </div>
  )
}

function SummaryToast({ visible, onDetail }: { visible: boolean; onDetail: () => void }) {
  return (
    <div style={{ position: 'absolute', bottom: 80, right: 20, width: 300, transition: 'opacity 0.4s ease, transform 0.4s cubic-bezier(0.34,1.56,0.64,1)', opacity: visible ? 1 : 0, transform: visible ? 'translateY(0)' : 'translateY(24px)', pointerEvents: visible ? 'auto' : 'none', zIndex: 30 }}>
      <div className="bg-white rounded-3xl p-4" style={{ boxShadow: '0 8px 32px rgba(58,52,46,0.15)', border: '1px solid #EDE8E1' }}>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs" style={{ backgroundColor: '#C1A7E2' }}>✓</div>
          <span className="text-[13px] font-bold" style={{ color: '#3A342E' }}>답변 요약이 완료되었습니다</span>
        </div>
        <div className="rounded-2xl p-3 mb-3" style={{ backgroundColor: '#EDF9F4' }}>
          <div className="text-[11px] font-bold mb-2" style={{ color: '#5BB898' }}>📋 대시보드 증상이 추가되었습니다</div>
          <ul className="flex flex-col gap-1">
            {['앞다리 절뚝임 (시작: 3일 전)', '계단 오르기 어려움 (시작: 3일 전)', '활동량 감소 (시작: 3일 전)'].map((s, i) => (
              <li key={i} className="flex items-center gap-1.5 text-[11.5px]" style={{ color: '#3A342E' }}>
                <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: '#9EDAC4' }} />{s}
              </li>
            ))}
          </ul>
        </div>
        <p className="text-[12px] mb-3 line-clamp-2" style={{ color: '#6B6460' }}>다리를 절고 계단 오르기를 힘들어하는 증상이 있다면, 슬개골 탈구나 관절 관련 상태가 있을지도 몰라요...</p>
        <button onClick={onDetail} className="w-full py-2.5 rounded-2xl text-[13px] font-bold text-white transition-opacity hover:opacity-85" style={{ background: 'linear-gradient(135deg, #9EDAC4 0%, #C1A7E2 100%)' }}>자세히 보기</button>
      </div>
    </div>
  )
}

function SummaryPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const conditions = [
    { name: '슬개골 탈구 (Patellar Luxation)', stat: '소형견의 약 38%에서 유사 증상 관찰', source: 'AVMA 2024' },
    { name: '관절염 (Osteoarthritis)', stat: '4살 소형견의 약 22%에서 보행 이상 발견', source: 'JVIM 2023' },
    { name: '연부조직 손상 (Soft Tissue Injury)', stat: '유사 증상의 약 18%에서 관찰', source: 'VCA Guidelines' },
  ]
  return (
    <>
      <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 40, backgroundColor: 'rgba(58,52,46,0.18)', opacity: open ? 1 : 0, pointerEvents: open ? 'auto' : 'none', transition: 'opacity 0.3s ease' }} />
      <div style={{ position: 'fixed', top: 0, right: 0, bottom: 0, width: 360, zIndex: 50, transform: open ? 'translateX(0)' : 'translateX(100%)', transition: 'transform 0.35s cubic-bezier(0.32,0.72,0,1)', backgroundColor: '#FDFCF9', boxShadow: '-8px 0 40px rgba(58,52,46,0.12)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div className="flex items-center justify-between px-6 py-5" style={{ borderBottom: '1px solid #EDE8E1' }}>
          <div><div className="text-[16px] font-black" style={{ color: '#3A342E' }}>답변 요약</div><div className="text-[11px] mt-0.5" style={{ color: '#B0A8A0' }}>뽀삐 · 오늘 오후 2:34</div></div>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors" style={{ color: '#6B6460', fontSize: 18 }}>×</button>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-5 flex flex-col gap-5">
          <div>
            <div className="flex items-center gap-2 mb-3"><div className="w-5 h-5 rounded-lg flex items-center justify-center text-[10px]" style={{ backgroundColor: '#9EDAC4' }}>📋</div><span className="text-[13px] font-bold" style={{ color: '#3A342E' }}>대시보드 업로드 정보</span></div>
            <div className="rounded-2xl p-4" style={{ backgroundColor: '#EDF9F4', border: '1px solid #C8EDE0' }}>
              <p className="text-[12px] font-semibold mb-3" style={{ color: '#5BB898' }}>대시보드 증상이 추가되었습니다</p>
              <ul className="flex flex-col gap-2">
                {[{ symptom: '앞다리 절뚝임', onset: '3일 전' }, { symptom: '계단 오르기 어려움', onset: '3일 전' }, { symptom: '활동량 감소', onset: '3일 전' }].map((s, i) => (
                  <li key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: '#9EDAC4' }} /><span className="text-[13px]" style={{ color: '#3A342E' }}>{s.symptom}</span></div>
                    <span className="text-[11px] px-2 py-0.5 rounded-full" style={{ backgroundColor: 'rgba(255,255,255,0.8)', color: '#8CC9B0' }}>시작: {s.onset}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div style={{ borderTop: '1px solid #EDE8E1' }} />
          <div>
            <div className="flex items-center gap-2 mb-1"><div className="w-5 h-5 rounded-lg flex items-center justify-center text-[10px]" style={{ backgroundColor: '#C1A7E2' }}>🔍</div><span className="text-[13px] font-bold" style={{ color: '#3A342E' }}>AI 예상 의심증상</span></div>
            <p className="text-[12px] mb-3" style={{ color: '#9A8FB0' }}>이런 증상이 있다면 이런 상태가 있을지도 모릅니다</p>
            <ul className="flex flex-col gap-3">
              {conditions.map((c, i) => (
                <li key={i} className="rounded-2xl p-3.5" style={{ backgroundColor: '#F8F5FF', border: '1px solid #E8DFF8' }}>
                  <div className="text-[13px] font-semibold mb-1" style={{ color: '#3A342E' }}>{c.name}</div>
                  <div className="text-[12px] mb-2" style={{ color: '#6B6460' }}>{c.stat}</div>
                  <button className="text-[11px] font-medium px-2.5 py-1 rounded-xl hover:opacity-70 transition-opacity" style={{ backgroundColor: '#EDE8F8', color: '#8B6FC7' }}>📎 {c.source}</button>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl px-4 py-3" style={{ backgroundColor: '#FFF9EC', border: '1px solid #FFE5A0' }}>
            <p className="text-[11.5px]" style={{ color: '#8A6E20' }}>💡 자세한 근거와 설명은 채팅 답변 전체를 확인해주세요. 이 요약은 참고용이며 수의사 진단을 대체하지 않아요.</p>
          </div>
        </div>
      </div>
    </>
  )
}

function ChatbotPage() {
  const [input, setInput] = useState('')
  const [showToast, setShowToast] = useState(false)
  const [panelOpen, setPanelOpen] = useState(false)
  const [typing, setTyping] = useState(false)
  const [aiResponseVisible, setAiResponseVisible] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  useEffect(() => { const t = setTimeout(() => setShowToast(true), 900); return () => clearTimeout(t) }, [])
  const handleSend = () => {
    if (!input.trim()) return
    setInput(''); setTyping(true); setShowToast(false); setAiResponseVisible(false)
    setTimeout(() => { setTyping(false); setAiResponseVisible(true); setTimeout(() => setShowToast(true), 500); messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, 2200)
  }
  return (
    <div className="flex-1 flex" style={{ minHeight: 0 }}>
      <div className="flex-1 flex flex-col" style={{ minWidth: 0 }}>
        <div className="flex-1 px-6 pt-5 pb-4" style={{ minHeight: 0 }}>
          <div className="relative rounded-3xl flex flex-col" style={{ backgroundColor: 'white', boxShadow: '0 2px 24px rgba(58,52,46,0.07)', border: '1px solid #EDE8E1', height: 'calc(100vh - 130px)', overflow: 'hidden' }}>
            <div className="flex items-center gap-3 px-6 py-4 flex-shrink-0" style={{ borderBottom: '1px solid #F0ECE8' }}>
              <div className="w-9 h-9 rounded-full flex items-center justify-center text-base" style={{ background: 'linear-gradient(135deg, #9EDAC4, #C1A7E2)' }}>🐾</div>
              <div>
                <div className="text-[14px] font-bold" style={{ color: '#3A342E' }}>Paw:Paw AI</div>
                <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: '#9EDAC4' }} /><span className="text-[11px]" style={{ color: '#8CC9B0' }}>온라인 · 뽀삐 케어 모드</span></div>
              </div>
              <div className="ml-auto"><span className="text-[11px] px-2.5 py-1 rounded-full font-semibold" style={{ backgroundColor: '#F4F0FB', color: '#9A75CC' }}>오늘 대화 3회</span></div>
            </div>
            <div className="flex-1 overflow-y-auto px-6 py-5 flex flex-col gap-4">
              <div className="flex gap-3 max-w-[80%]">
                <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-sm" style={{ background: 'linear-gradient(135deg, #9EDAC4, #C1A7E2)' }}>🐾</div>
                <div>
                  <div className="text-[11px] mb-1.5" style={{ color: '#B0A8A0' }}>Paw:Paw AI · 오후 2:30</div>
                  <div className="rounded-[20px] rounded-tl-sm px-4 py-3 text-[13.5px] leading-relaxed" style={{ backgroundColor: '#FDFCF9', border: '1px solid #EDE8E1', color: '#3A342E' }}>
                    안녕하세요! 뽀삐 보호자님 😊<br />오늘은 뽀삐에 대해 어떤 이야기를 해드릴까요?<br /><span style={{ color: '#9A9086' }}>증상이나 걱정되는 점을 편하게 말씀해주세요.</span>
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <div>
                  <div className="text-[11px] text-right mb-1.5" style={{ color: '#B0A8A0' }}>오후 2:32</div>
                  <div className="rounded-[20px] rounded-tr-sm px-4 py-3 text-[13.5px] leading-relaxed" style={{ backgroundColor: '#F0ECF8', color: '#3A342E', maxWidth: 320 }}>
                    뽀삐가 며칠 전부터 오른쪽 앞다리를 자꾸 절고 있어요. 계단도 잘 못 올라가고 평소보다 많이 지쳐 보여요 😟
                  </div>
                </div>
              </div>
              {aiResponseVisible && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-sm mt-6" style={{ background: 'linear-gradient(135deg, #9EDAC4, #C1A7E2)' }}>🐾</div>
                  <div>
                    <div className="text-[11px] mb-1.5" style={{ color: '#B0A8A0' }}>Paw:Paw AI · 오후 2:34</div>
                    <div className="rounded-[20px] rounded-tl-sm px-5 py-4" style={{ backgroundColor: '#FDFCF9', border: '1px solid #EDE8E1', maxWidth: 560 }}><AiResponseBody /></div>
                  </div>
                </div>
              )}
              {typing && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-sm" style={{ background: 'linear-gradient(135deg, #9EDAC4, #C1A7E2)' }}>🐾</div>
                  <div className="rounded-[20px] rounded-tl-sm px-4 py-3" style={{ backgroundColor: '#FDFCF9', border: '1px solid #EDE8E1' }}><TypingDots /></div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
            <div className="absolute bottom-[68px] left-4 pointer-events-none select-none" style={{ opacity: 0.85 }}><ChatDogDecor /></div>
            <SummaryToast visible={showToast} onDetail={() => { setShowToast(false); setPanelOpen(true) }} />
            <div className="flex-shrink-0 px-5 py-3.5" style={{ borderTop: '1px solid #F0ECE8' }}>
              <div className="flex items-center gap-3">
                <div className="w-14" />
                <div className="flex-1 flex items-center gap-3 rounded-2xl px-4 py-2.5" style={{ backgroundColor: '#F7F4F1', border: '1.5px solid #EDE8E1' }}>
                  <input type="text" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} placeholder="증상이나 질문을 입력해주세요" className="flex-1 bg-transparent outline-none text-[13.5px]" style={{ color: '#3A342E' }} />
                </div>
                <button onClick={handleSend} className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-transform hover:scale-105 active:scale-95" style={{ background: input.trim() ? 'linear-gradient(135deg, #9EDAC4, #C1A7E2)' : '#E8E3DC', boxShadow: input.trim() ? '0 3px 12px rgba(158,218,196,0.4)' : 'none' }}>
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M9 14V4M9 4L5 8M9 4L13 8" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </button>
              </div>
              <p className="text-center text-[10.5px] mt-2" style={{ color: '#C0BAB4' }}>AI 답변은 참고용이며 수의사 진단을 대체하지 않아요</p>
            </div>
          </div>
        </div>
      </div>
      <SummaryPanel open={panelOpen} onClose={() => setPanelOpen(false)} />
    </div>
  )
}

// ─── Root App ──────────────────────────────────────────────────────────────
export default function App() {
  const [activeNav, setActiveNav] = useState<NavId>('dashboard')
  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#FDFCF9', color: '#3A342E', fontFamily: "'Noto Sans KR', sans-serif" }}>
      <Navbar activeNav={activeNav} setActiveNav={setActiveNav} />
      {activeNav === 'dashboard' && <FullDashboardPage onChatbot={() => setActiveNav('chatbot')} />}
      {activeNav === 'chatbot' && <ChatbotPage />}
      {(activeNav === 'report' || activeNav === 'mypet') && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="text-5xl mb-4">🐾</div>
            <div className="text-[16px] font-semibold" style={{ color: '#B0A8A0' }}>준비 중이에요</div>
            <div className="text-[13px] mt-1" style={{ color: '#C0BAB4' }}>곧 만나볼 수 있어요!</div>
          </div>
        </div>
      )}
    </div>
  )
}
