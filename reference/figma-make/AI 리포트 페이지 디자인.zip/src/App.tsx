import { useState } from 'react'

// ── Design tokens ─────────────────────────────────────────────
const MINT = '#9EDAC4'
const PURPLE = '#C1A7E2'
const IVORY = '#FDFCF9'
const DARK = '#3A342E'
const YELLOW = '#F5D98B'
const GRAY_LIGHT = '#F2EFE9'
const MUTED = '#8A7F78'
const BORDER = '#E8E3DC'
const CARD_BG = '#FBF7ED'

// ── Types ─────────────────────────────────────────────────────
type Screen =
  | 'mypage'
  | 'edit-user'
  | 'pet-list'
  | 'pet-settings'
  | 'notifications'
  | 'dashboard-settings'

interface Pet {
  id: number
  name: string
  species: string
  breed: string
  birthdate: string
  emoji: string
}

// ── Sample data ───────────────────────────────────────────────
const PETS: Pet[] = [
  { id: 1, name: '뽀삐', species: '고양이', breed: '코리안 숏헤어', birthdate: '2023-04-12', emoji: '🐱' },
  { id: 2, name: '망고', species: '강아지', breed: '말티즈', birthdate: '2021-08-30', emoji: '🐶' },
]

function calcAge(birthdate: string): string {
  const birth = new Date(birthdate)
  const now = new Date()
  let years = now.getFullYear() - birth.getFullYear()
  const m = now.getMonth() - birth.getMonth()
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) years--
  return `만 ${years}세`
}

// ── Shared NavBar ─────────────────────────────────────────────
function NavBar({ active }: { active: string }) {
  return (
    <header style={{ backgroundColor: IVORY, borderBottom: `1px solid ${BORDER}`, position: 'sticky', top: 0, zIndex: 50 }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px', height: 64, display: 'flex', alignItems: 'center', gap: 32 }}>
        <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1, flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
              <circle cx="14" cy="14" r="14" fill="url(#pawGrad)" />
              <defs>
                <linearGradient id="pawGrad" x1="0" y1="0" x2="28" y2="28">
                  <stop stopColor={MINT} />
                  <stop offset="1" stopColor={PURPLE} />
                </linearGradient>
              </defs>
              <text x="14" y="18.5" textAnchor="middle" fontSize="14" fill="white">🐾</text>
            </svg>
            <span style={{ fontWeight: 700, fontSize: 17 }}>
              <span style={{ color: DARK }}>Paw:</span>
              <span style={{ color: PURPLE }}>Paw</span>
            </span>
          </div>
          <span style={{ fontSize: 10, color: MUTED, marginLeft: 34 }}>우리 아이의 하루를, AI가 함께 돌봐요</span>
        </div>

        <nav style={{ display: 'flex', gap: 8, flex: 1, justifyContent: 'center' }}>
          {['대시보드', 'AI챗봇', 'AI 리포트', '마이페이지'].map((item) => {
            const isActive = item === active
            return (
              <button key={item} style={{ padding: '7px 18px', borderRadius: 20, border: 'none', cursor: 'pointer', fontWeight: isActive ? 600 : 400, fontSize: 14, background: isActive ? MINT : 'transparent', color: isActive ? '#fff' : DARK, transition: 'background 0.15s' }}>
                {item}
              </button>
            )
          })}
        </nav>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
          <span style={{ fontSize: 13, color: DARK, fontWeight: 500 }}>김지수 님</span>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: `linear-gradient(135deg, ${MINT}, ${PURPLE})`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, cursor: 'pointer' }}>
            🐱
          </div>
        </div>
      </div>
    </header>
  )
}

// ── Floating chat button ──────────────────────────────────────
function FloatingChat() {
  return (
    <button style={{ position: 'fixed', bottom: 32, right: 32, width: 56, height: 56, borderRadius: '50%', background: `linear-gradient(135deg, ${MINT}, ${PURPLE})`, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, boxShadow: '0 4px 18px rgba(158,218,196,0.45)', zIndex: 100 }} title="AI 챗봇으로 이동">
      💬
    </button>
  )
}

// ── Back button ───────────────────────────────────────────────
function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <button onClick={onClick} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 14px', borderRadius: 20, border: `1px solid ${BORDER}`, background: '#fff', color: DARK, fontSize: 13, cursor: 'pointer', marginBottom: 24, fontWeight: 500 }}>
      ← 마이페이지로
    </button>
  )
}

// ── Section title ─────────────────────────────────────────────
function PageTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div style={{ marginBottom: 28 }}>
      <h1 style={{ fontSize: 24, fontWeight: 700, color: DARK, margin: 0 }}>{title}</h1>
      {subtitle && <p style={{ fontSize: 13, color: MUTED, margin: '4px 0 0' }}>{subtitle}</p>}
    </div>
  )
}

// ── Card wrapper ──────────────────────────────────────────────
function SettingCard({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ background: CARD_BG, borderRadius: 20, border: `1px solid ${BORDER}`, boxShadow: '0 2px 12px rgba(58,52,46,0.06)', overflow: 'hidden', marginBottom: 16 }}>
      {children}
    </div>
  )
}

function CardHeader({ label }: { label: string }) {
  return (
    <div style={{ background: '#fff', borderBottom: `1px solid ${BORDER}`, padding: '13px 24px' }}>
      <span style={{ fontWeight: 700, fontSize: 15, color: DARK }}>{label}</span>
    </div>
  )
}

// ── Menu link row ─────────────────────────────────────────────
function MenuRow({ icon, label, desc, onClick }: { icon: string; label: string; desc?: string; onClick: () => void }) {
  const [hovered, setHovered] = useState(false)
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 14, padding: '16px 24px', background: hovered ? `${YELLOW}55` : 'transparent', border: 'none', cursor: 'pointer', textAlign: 'left', transition: 'background 0.15s', borderBottom: `1px solid ${BORDER}` }}
    >
      <div style={{ width: 36, height: 36, borderRadius: 10, background: `${YELLOW}88`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>
        {icon}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 500, color: hovered ? PURPLE : DARK, textDecoration: hovered ? 'underline' : 'none', transition: 'color 0.15s' }}>
          {label}
        </div>
        {desc && <div style={{ fontSize: 12, color: MUTED, marginTop: 2 }}>{desc}</div>}
      </div>
      <span style={{ color: MUTED, fontSize: 16 }}>›</span>
    </button>
  )
}

// ────────────────────────────────────────────────────────────
// SCREENS
// ────────────────────────────────────────────────────────────

// 1. Main mypage ───────────────────────────────────────────────
function MyPage({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <>
      <NavBar active="마이페이지" />
      <main style={{ maxWidth: 680, margin: '0 auto', padding: '40px 24px 80px' }}>
        <PageTitle title="마이페이지" />

        {/* Profile mini */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 36, padding: '18px 22px', background: '#fff', borderRadius: 18, border: `1px solid ${BORDER}`, boxShadow: '0 2px 8px rgba(58,52,46,0.05)' }}>
          <div style={{ width: 56, height: 56, borderRadius: '50%', background: `linear-gradient(135deg, ${MINT}55, ${PURPLE}55)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, border: `2px solid ${MINT}` }}>
            👤
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 17, color: DARK }}>김지수 님</div>
            <div style={{ fontSize: 12, color: MUTED, marginTop: 2 }}>반려동물 2마리 등록됨</div>
          </div>
        </div>

        {/* 계정 card */}
        <SettingCard>
          <CardHeader label="계정" />
          <MenuRow icon="✏️" label="내 정보 수정하기" desc="성함, 나이, 인증 사진 변경" onClick={() => navigate('edit-user')} />
          <div style={{ borderBottom: 'none' }}>
            <MenuRow icon="🐾" label="반려동물 정보 수정하기" desc="등록된 반려동물 프로필 관리" onClick={() => navigate('pet-list')} />
          </div>
        </SettingCard>

        {/* 설정 card */}
        <SettingCard>
          <CardHeader label="설정" />
          <MenuRow icon="🔔" label="알림 설정" desc="카카오톡 채널 알림 on/off" onClick={() => navigate('notifications')} />
          <div style={{ borderBottom: 'none' }}>
            <MenuRow icon="📊" label="대시보드 및 리포트 설정" desc="표시 항목, 리포트 주기 커스터마이징" onClick={() => navigate('dashboard-settings')} />
          </div>
        </SettingCard>
      </main>
      <FloatingChat />
    </>
  )
}

// 2. Edit user info ────────────────────────────────────────────
function EditUserScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [name, setName] = useState('김지수')
  const [age, setAge] = useState('29')
  const [saved, setSaved] = useState(false)

  function handleSave() {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <>
      <NavBar active="마이페이지" />
      <main style={{ maxWidth: 560, margin: '0 auto', padding: '40px 24px 80px' }}>
        <BackButton onClick={() => navigate('mypage')} />
        <PageTitle title="내 정보 수정" subtitle="반려인 프로필을 수정할 수 있어요" />

        <div style={{ background: '#fff', borderRadius: 20, border: `1px solid ${BORDER}`, padding: 28, boxShadow: '0 2px 12px rgba(58,52,46,0.06)' }}>
          {/* Profile photo */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: 28 }}>
            <div style={{ width: 80, height: 80, borderRadius: '50%', background: `linear-gradient(135deg, ${MINT}55, ${PURPLE}55)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 38, border: `3px solid ${MINT}`, marginBottom: 10 }}>
              👤
            </div>
            <button style={{ fontSize: 12, color: PURPLE, background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600, textDecoration: 'underline' }}>
              인증 사진 변경
            </button>
          </div>

          {/* Fields */}
          {[
            { label: '성함', value: name, setter: setName, placeholder: '이름을 입력하세요' },
            { label: '나이', value: age, setter: setAge, placeholder: '나이를 입력하세요' },
          ].map(({ label, value, setter, placeholder }) => (
            <div key={label} style={{ marginBottom: 18 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: MUTED, display: 'block', marginBottom: 6 }}>{label}</label>
              <input
                value={value}
                onChange={(e) => setter(e.target.value)}
                placeholder={placeholder}
                style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: `1px solid ${BORDER}`, fontSize: 14, color: DARK, background: IVORY, outline: 'none', boxSizing: 'border-box' }}
              />
            </div>
          ))}

          <button
            onClick={handleSave}
            style={{ width: '100%', marginTop: 8, padding: '13px', borderRadius: 14, border: 'none', background: saved ? MINT : `linear-gradient(135deg, ${MINT}, ${PURPLE})`, color: '#fff', fontWeight: 700, fontSize: 15, cursor: 'pointer', transition: 'background 0.2s' }}
          >
            {saved ? '저장되었어요 ✓' : '저장하기'}
          </button>
        </div>
      </main>
      <FloatingChat />
    </>
  )
}

// 3. Pet list ─────────────────────────────────────────────────
function PetListScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <>
      <NavBar active="마이페이지" />
      <main style={{ maxWidth: 680, margin: '0 auto', padding: '40px 24px 80px' }}>
        <BackButton onClick={() => navigate('mypage')} />
        <PageTitle title="반려동물 프로필" subtitle="등록된 반려동물 정보를 관리해요" />

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {PETS.map((pet) => (
            <div key={pet.id} style={{ background: '#fff', borderRadius: 20, border: `1px solid ${BORDER}`, padding: '20px 24px', boxShadow: '0 2px 10px rgba(58,52,46,0.06)', display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{ width: 58, height: 58, borderRadius: '50%', background: `linear-gradient(135deg, ${MINT}44, ${PURPLE}44)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, border: `2px solid ${MINT}`, flexShrink: 0 }}>
                {pet.emoji}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 16, color: DARK }}>{pet.name}</div>
                <div style={{ fontSize: 12, color: MUTED, marginTop: 2 }}>{pet.species} · {pet.breed} · {calcAge(pet.birthdate)}</div>
                <div style={{ fontSize: 11, color: MUTED, marginTop: 1 }}>생일 {pet.birthdate}</div>
              </div>
              <button
                onClick={() => navigate('pet-settings')}
                style={{ padding: '8px 18px', borderRadius: 20, border: 'none', background: MINT, color: '#fff', fontSize: 12, fontWeight: 600, cursor: 'pointer', flexShrink: 0 }}
              >
                대시보드 설정하기
              </button>
            </div>
          ))}

          {/* Add pet */}
          <button
            onClick={() => navigate('pet-settings')}
            style={{ borderRadius: 20, border: `2px dashed ${BORDER}`, background: 'transparent', padding: '20px 24px', display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer', width: '100%' }}
          >
            <div style={{ width: 58, height: 58, borderRadius: '50%', border: `2px dashed ${MINT}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, color: MINT }}>
              +
            </div>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontWeight: 600, fontSize: 14, color: MINT }}>반려동물 추가하기</div>
              <div style={{ fontSize: 12, color: MUTED, marginTop: 2 }}>새로운 반려동물 프로필을 등록해요</div>
            </div>
          </button>
        </div>
      </main>
      <FloatingChat />
    </>
  )
}

// 4. Pet dashboard settings ───────────────────────────────────
function PetSettingsScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [petName, setPetName] = useState('뽀삐')
  const [breed, setBreed] = useState('코리안 숏헤어')
  const [birth, setBirth] = useState('2023-04-12')
  const [saved, setSaved] = useState(false)

  function handleSave() {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <>
      <NavBar active="마이페이지" />
      <main style={{ maxWidth: 560, margin: '0 auto', padding: '40px 24px 80px' }}>
        <BackButton onClick={() => navigate('pet-list')} />
        <PageTitle title="반려동물 정보 설정" subtitle="대시보드와 리포트에 반영될 정보를 입력해요" />

        <div style={{ background: '#fff', borderRadius: 20, border: `1px solid ${BORDER}`, padding: 28, boxShadow: '0 2px 12px rgba(58,52,46,0.06)' }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 24 }}>
            <div style={{ width: 80, height: 80, borderRadius: '50%', background: `linear-gradient(135deg, ${MINT}55, ${PURPLE}55)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 38, border: `3px solid ${MINT}` }}>
              🐱
            </div>
          </div>

          {[
            { label: '이름', value: petName, setter: setPetName },
            { label: '품종', value: breed, setter: setBreed },
            { label: '생년월일', value: birth, setter: setBirth, type: 'date' },
          ].map(({ label, value, setter, type }) => (
            <div key={label} style={{ marginBottom: 18 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: MUTED, display: 'block', marginBottom: 6 }}>{label}</label>
              <input
                type={type ?? 'text'}
                value={value}
                onChange={(e) => setter(e.target.value)}
                style={{ width: '100%', padding: '11px 14px', borderRadius: 12, border: `1px solid ${BORDER}`, fontSize: 14, color: DARK, background: IVORY, outline: 'none', boxSizing: 'border-box' }}
              />
            </div>
          ))}

          {birth && (
            <div style={{ background: `${MINT}22`, borderRadius: 10, padding: '10px 14px', marginBottom: 18, fontSize: 13, color: DARK }}>
              🎂 자동 계산된 나이: <strong>{calcAge(birth)}</strong>
            </div>
          )}

          <button onClick={handleSave} style={{ width: '100%', padding: '13px', borderRadius: 14, border: 'none', background: saved ? MINT : `linear-gradient(135deg, ${MINT}, ${PURPLE})`, color: '#fff', fontWeight: 700, fontSize: 15, cursor: 'pointer', transition: 'background 0.2s' }}>
            {saved ? '저장되었어요 ✓' : '저장하기'}
          </button>
        </div>
      </main>
      <FloatingChat />
    </>
  )
}

// 5. Notification settings ────────────────────────────────────
type NotifKey = 'medication' | 'dday' | 'weekly' | 'emergency'

function NotificationScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [toggles, setToggles] = useState<Record<NotifKey, boolean>>({
    medication: true,
    dday: true,
    weekly: false,
    emergency: true,
  })

  const items: { key: NotifKey; icon: string; label: string; desc: string }[] = [
    { key: 'medication', icon: '💊', label: '복약 알림', desc: '약 복용 시간에 카카오톡 채널 메시지 발송' },
    { key: 'dday', icon: '📅', label: '디데이 리마인드', desc: '병원 예약·예방접종 1주전, 1일전, 당일 알림' },
    { key: 'weekly', icon: '📋', label: '주간 리포트 알림', desc: '매주 월요일 주간 건강 요약 발송' },
    { key: 'emergency', icon: '⚠️', label: '이상 징후 경고', desc: 'AI가 이상 패턴 감지 시 즉시 알림' },
  ]

  function toggle(key: NotifKey) {
    setToggles((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <>
      <NavBar active="마이페이지" />
      <main style={{ maxWidth: 560, margin: '0 auto', padding: '40px 24px 80px' }}>
        <BackButton onClick={() => navigate('mypage')} />
        <PageTitle title="알림 설정" subtitle="카카오톡 채널로 받을 알림을 선택해요" />

        {/* Kakao badge */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: '#FEE500', borderRadius: 14, padding: '12px 18px', marginBottom: 24 }}>
          <span style={{ fontSize: 18 }}>💛</span>
          <span style={{ fontSize: 13, fontWeight: 600, color: '#3A1D1D' }}>카카오톡 채널 "Paw:Paw" 연결됨</span>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 0, background: '#fff', borderRadius: 20, border: `1px solid ${BORDER}`, overflow: 'hidden', boxShadow: '0 2px 12px rgba(58,52,46,0.06)' }}>
          {items.map((item, i) => (
            <div key={item.key} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '18px 22px', borderBottom: i < items.length - 1 ? `1px solid ${BORDER}` : 'none' }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: GRAY_LIGHT, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>
                {item.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: DARK }}>{item.label}</div>
                <div style={{ fontSize: 12, color: MUTED, marginTop: 2 }}>{item.desc}</div>
              </div>
              {/* Toggle */}
              <div
                onClick={() => toggle(item.key)}
                style={{ width: 46, height: 26, borderRadius: 13, background: toggles[item.key] ? MINT : BORDER, cursor: 'pointer', position: 'relative', transition: 'background 0.2s', flexShrink: 0 }}
              >
                <div style={{ width: 20, height: 20, borderRadius: '50%', background: '#fff', position: 'absolute', top: 3, left: toggles[item.key] ? 23 : 3, transition: 'left 0.2s', boxShadow: '0 1px 4px rgba(0,0,0,0.15)' }} />
              </div>
            </div>
          ))}
        </div>
      </main>
      <FloatingChat />
    </>
  )
}

// 6. Dashboard & report settings ──────────────────────────────
type Period = '일간' | '주간' | '월간'

function DashboardSettingsScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [period, setPeriod] = useState<Period>('주간')
  const [widgets, setWidgets] = useState({ weight: true, medication: true, symptoms: true, calendar: false, aiReport: true })
  const [saved, setSaved] = useState(false)

  type WidgetKey = keyof typeof widgets
  const widgetItems: { key: WidgetKey; label: string; desc: string }[] = [
    { key: 'weight', label: '체중 그래프', desc: '체중 변화 추이 카드' },
    { key: 'medication', label: '복약 현황', desc: '오늘의 복약 진행률' },
    { key: 'symptoms', label: '증상 기록', desc: '최근 증상 타임라인' },
    { key: 'calendar', label: '일정 캘린더', desc: '예약·디데이 월간 캘린더' },
    { key: 'aiReport', label: 'AI 리포트 요약', desc: '월간 AI 분석 핵심 요약' },
  ]

  function handleSave() {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <>
      <NavBar active="마이페이지" />
      <main style={{ maxWidth: 560, margin: '0 auto', padding: '40px 24px 80px' }}>
        <BackButton onClick={() => navigate('mypage')} />
        <PageTitle title="대시보드 및 리포트 설정" subtitle="대시보드에 표시할 위젯과 리포트 주기를 설정해요" />

        {/* Report period */}
        <div style={{ background: '#fff', borderRadius: 20, border: `1px solid ${BORDER}`, padding: '20px 24px', marginBottom: 16, boxShadow: '0 2px 10px rgba(58,52,46,0.06)' }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: DARK, marginBottom: 14 }}>리포트 주기</div>
          <div style={{ display: 'flex', gap: 8 }}>
            {(['일간', '주간', '월간'] as Period[]).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                style={{ flex: 1, padding: '10px', borderRadius: 12, border: `1.5px solid ${period === p ? MINT : BORDER}`, background: period === p ? `${MINT}22` : '#fff', color: period === p ? DARK : MUTED, fontWeight: period === p ? 700 : 400, fontSize: 14, cursor: 'pointer', transition: 'all 0.15s' }}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Widget toggles */}
        <div style={{ background: '#fff', borderRadius: 20, border: `1px solid ${BORDER}`, overflow: 'hidden', marginBottom: 20, boxShadow: '0 2px 10px rgba(58,52,46,0.06)' }}>
          <div style={{ padding: '16px 24px 12px', borderBottom: `1px solid ${BORDER}` }}>
            <span style={{ fontWeight: 700, fontSize: 14, color: DARK }}>대시보드 표시 항목</span>
          </div>
          {widgetItems.map((w, i) => (
            <div key={w.key} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '15px 22px', borderBottom: i < widgetItems.length - 1 ? `1px solid ${BORDER}` : 'none' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 500, color: DARK }}>{w.label}</div>
                <div style={{ fontSize: 12, color: MUTED, marginTop: 1 }}>{w.desc}</div>
              </div>
              <div
                onClick={() => setWidgets((prev) => ({ ...prev, [w.key]: !prev[w.key] }))}
                style={{ width: 46, height: 26, borderRadius: 13, background: widgets[w.key] ? PURPLE : BORDER, cursor: 'pointer', position: 'relative', transition: 'background 0.2s', flexShrink: 0 }}
              >
                <div style={{ width: 20, height: 20, borderRadius: '50%', background: '#fff', position: 'absolute', top: 3, left: widgets[w.key] ? 23 : 3, transition: 'left 0.2s', boxShadow: '0 1px 4px rgba(0,0,0,0.15)' }} />
              </div>
            </div>
          ))}
        </div>

        <button onClick={handleSave} style={{ width: '100%', padding: '13px', borderRadius: 14, border: 'none', background: saved ? MINT : `linear-gradient(135deg, ${MINT}, ${PURPLE})`, color: '#fff', fontWeight: 700, fontSize: 15, cursor: 'pointer', transition: 'background 0.2s' }}>
          {saved ? '저장되었어요 ✓' : '설정 저장하기'}
        </button>
      </main>
      <FloatingChat />
    </>
  )
}

// ── Router ────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>('mypage')

  const navigate = (s: Screen) => setScreen(s)

  return (
    <div style={{ minHeight: '100vh', background: IVORY, fontFamily: "'Pretendard Variable', 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif", color: DARK }}>
      {screen === 'mypage' && <MyPage navigate={navigate} />}
      {screen === 'edit-user' && <EditUserScreen navigate={navigate} />}
      {screen === 'pet-list' && <PetListScreen navigate={navigate} />}
      {screen === 'pet-settings' && <PetSettingsScreen navigate={navigate} />}
      {screen === 'notifications' && <NotificationScreen navigate={navigate} />}
      {screen === 'dashboard-settings' && <DashboardSettingsScreen navigate={navigate} />}
    </div>
  )
}
